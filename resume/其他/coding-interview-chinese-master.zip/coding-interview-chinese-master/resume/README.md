# 简历以及Latex模板
这个repo里面放了程序员中文版简历的latex模板。

<object data="./resume-chinese.pdf" type="application/pdf" width="700px" height="700px"> 
    <embed src="./resume-chinese.pdf"> 
     This browser does not support PDFs. Please download the PDF to view it: <a href="./resume-chinese.pdf">Download PDF</a>.</p> 
    </embed> 
</object> 


# [英文Latex模板](https://github.com/sb2nov/resume)
### Preview
![Resume Screenshot](https://raw.githubusercontent.com/sb2nov/resume/master/resume_preview.png)
